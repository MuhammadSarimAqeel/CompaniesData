export class ObjectExperian {
    name!:string
    city!: string
    state!: string
    subcode!: string
    street!:  string
    zip!: number
    phone!: string
  
 }
export class Object {
   name!:string;
   country!:string;
}